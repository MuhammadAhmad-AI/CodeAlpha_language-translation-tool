"""Task 1: Language Translation Tool (Streamlit + Google Translate)

Features
- Text input with source & target language selection (auto-detect supported)
- Translation via Google Translate (deep-translator library, no API key needed)
- Translated text displayed clearly on screen
- Optional: Copy-to-clipboard button and text-to-speech (gTTS)
"""
import io
import json
import re

import requests
import streamlit as st
import streamlit.components.v1 as components
from deep_translator import GoogleTranslator
from gtts import gTTS

st.set_page_config(page_title="Language Translation Tool", page_icon="🌐", layout="centered")

# {display name: language code}
LANGUAGES = GoogleTranslator().get_supported_languages(as_dict=True)
LANG_NAMES = sorted(name.title() for name in LANGUAGES)
NAME_TO_CODE = {name.title(): code for name, code in LANGUAGES.items()}


def _chunks(text: str, limit: int):
    """Split text into pieces <= limit chars, preferably at sentence/line boundaries."""
    parts, cur = [], ""
    for piece in re.split(r"(?<=[.!?۔؟\n])\s+", text.strip()):
        while len(piece) > limit:  # very long sentence: hard split
            if cur:
                parts.append(cur)
                cur = ""
            parts.append(piece[:limit])
            piece = piece[limit:]
        if len(cur) + len(piece) + 1 > limit and cur:
            parts.append(cur)
            cur = piece
        else:
            cur = f"{cur} {piece}".strip()
    if cur:
        parts.append(cur)
    return parts


def _google_deep_translator(text, source, target):
    return GoogleTranslator(source=source, target=target).translate(text)


def _google_gtx(text, source, target):
    """Google's translate API endpoint (different host from translate.google.com, rarely CAPTCHA-blocked)."""
    out = []
    for part in _chunks(text, 1500):
        r = requests.get(
            "https://translate.googleapis.com/translate_a/single",
            params={"client": "gtx", "sl": source, "tl": target, "dt": "t", "q": part},
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=15,
        )
        r.raise_for_status()
        out.append("".join(seg[0] for seg in r.json()[0] if seg and seg[0]))
    return " ".join(out)


def _mymemory(text, source, target):
    """MyMemory free translation API (last resort, ~500 chars per request)."""
    langpair = f"{'Autodetect' if source == 'auto' else source}|{target}"
    out = []
    for part in _chunks(text, 450):
        r = requests.get("https://api.mymemory.translated.net/get",
                         params={"q": part, "langpair": langpair}, timeout=15)
        r.raise_for_status()
        out.append(r.json()["responseData"]["translatedText"])
    return " ".join(out)


def translate(text: str, source: str, target: str) -> str:
    """Try several translation backends in turn so one being blocked doesn't break the app."""
    errors = []
    for name, fn in [("Google", _google_deep_translator),
                     ("Google (gtx)", _google_gtx),
                     ("MyMemory", _mymemory)]:
        try:
            result = fn(text, source, target)
            if result and result.strip():
                return result
        except Exception as exc:
            errors.append(f"{name}: {type(exc).__name__}")
    raise RuntimeError("All translation services failed (" + "; ".join(errors) +
                       "). Check your internet connection, turn off VPN/proxy, or try again in a few minutes.")


def speak(text: str, lang_code: str) -> bytes:
    buf = io.BytesIO()
    gTTS(text=text, lang=lang_code.split("-")[0]).write_to_fp(buf)
    return buf.getvalue()


def copy_button(text: str) -> None:
    safe = json.dumps(text)
    components.html(
        f"""
        <button id="copy" style="padding:8px 16px;border-radius:6px;border:1px solid #888;
                cursor:pointer;font-size:14px;">📋 Copy translation</button>
        <span id="msg" style="margin-left:8px;font-family:sans-serif;color:green;"></span>
        <script>
          document.getElementById('copy').onclick = async () => {{
            await navigator.clipboard.writeText({safe});
            document.getElementById('msg').innerText = 'Copied!';
          }};
        </script>
        """,
        height=50,
    )


st.title("🌐 Language Translation Tool")
st.caption("Enter text, choose languages, and get the translation instantly.")

col1, col2 = st.columns(2)
with col1:
    source_name = st.selectbox("From", ["Auto Detect"] + LANG_NAMES, index=0)
with col2:
    target_name = st.selectbox("To", LANG_NAMES, index=LANG_NAMES.index("Urdu") if "Urdu" in LANG_NAMES else 0)

text = st.text_area("Enter text to translate", height=150, max_chars=5000,
                    placeholder="Type or paste your text here...")

if st.button("Translate", type="primary"):
    if not text.strip():
        st.warning("Please enter some text first.")
    else:
        source = "auto" if source_name == "Auto Detect" else NAME_TO_CODE[source_name]
        target = NAME_TO_CODE[target_name]
        try:
            with st.spinner("Translating..."):
                st.session_state["result"] = translate(text, source, target)
                st.session_state["target"] = target
        except Exception as exc:  # network / API errors
            st.error(f"Translation failed: {exc}")

if "result" in st.session_state:
    st.subheader("Translated text")
    st.success(st.session_state["result"])
    copy_button(st.session_state["result"])

    if st.button("🔊 Listen"):
        try:
            st.audio(speak(st.session_state["result"], st.session_state["target"]), format="audio/mp3")
        except Exception as exc:
            st.error(f"Text-to-speech not available for this language: {exc}")
